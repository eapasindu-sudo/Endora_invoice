<?php
/**
 * Plugin Name: Endora MCP
 * Description: Lets Claude work on this site and server (files, disk space, database, PHP) through a secret-token protected MCP connector. Every call is logged. Write, delete and PHP access are OFF until you switch them on in the Endora MCP menu.
 * Version: 1.0.2
 * Author: Endora Wedding Films
 */
if (!defined('ABSPATH')) {
    exit;
}

final class Endora_MCP
{
    const OPT = 'endora_mcp_settings';
    const LOG = 'endora_mcp_log';
    const PROTOCOL = '2025-03-26';
    const VERSION = '1.0.2';
    const UPDATE_JSON = 'https://raw.githubusercontent.com/eapasindu-sudo/Endora_invoice/endora-mcp/endora-mcp.json';

    /* ------------------------------------------------------------ settings */
    public static function settings()
    {
        $d = ['token_hash' => '', 'allow_write' => 0, 'allow_delete' => 0, 'allow_php' => 0, 'allow_db_write' => 0, 'root' => ''];
        return array_merge($d, (array) get_option(self::OPT, []));
    }

    public static function root()
    {
        $s = self::settings();
        $r = $s['root'] !== '' ? $s['root'] : dirname(rtrim(ABSPATH, '/'));
        $r = realpath($r);
        return $r ? rtrim($r, '/') : rtrim(ABSPATH, '/');
    }

    /* ------------------------------------------------------------ boot */
    public static function init()
    {
        add_action('rest_api_init', function () {
            register_rest_route('endora-mcp/v1', '/mcp', [
                ['methods' => 'POST', 'callback' => [__CLASS__, 'handle'], 'permission_callback' => '__return_true'],
                ['methods' => 'GET,DELETE', 'callback' => function () { return new WP_REST_Response(['error' => 'Use POST'], 405); }, 'permission_callback' => '__return_true'],
            ]);
        });
        add_action('admin_menu', function () {
            add_menu_page('Endora MCP', 'Endora MCP', 'manage_options', 'endora-mcp', [__CLASS__, 'admin_page'], 'dashicons-shield', 3);
        });
        // Updates appear on the normal Plugins page ("update now"): the newest version is read from a small JSON file on GitHub.
        add_filter('pre_set_site_transient_update_plugins', function ($t) {
            if (!is_object($t)) {
                return $t;
            }
            $j = get_transient('endora_mcp_update');
            if ($j === false) {
                $r = wp_remote_get(self::UPDATE_JSON, ['timeout' => 10]);
                $j = (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) ? json_decode(wp_remote_retrieve_body($r), true) : [];
                set_transient('endora_mcp_update', is_array($j) ? $j : [], 6 * HOUR_IN_SECONDS);
            }
            $base = plugin_basename(__FILE__);
            if (!empty($j['version']) && !empty($j['zip']) && version_compare($j['version'], self::VERSION, '>') && strpos($j['zip'], 'https://raw.githubusercontent.com/eapasindu-sudo/') === 0) {
                $t->response[$base] = (object) ['slug' => 'endora-mcp', 'plugin' => $base, 'new_version' => $j['version'], 'package' => $j['zip'], 'url' => 'https://www.endoraweddingfilms.com'];
            }
            return $t;
        });
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
            array_unshift($links, '<a href="' . esc_url(admin_url('admin.php?page=endora-mcp')) . '">Settings</a>');
            return $links;
        });
    }

    /* ------------------------------------------------------------ auth */
    private static function ip()
    {
        return substr((string) ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
    }

    private static function bearer()
    {
        $h = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if ($h === '' && function_exists('getallheaders')) {
            foreach (getallheaders() as $k => $v) {
                if (strtolower($k) === 'authorization') {
                    $h = $v;
                }
            }
        }
        return preg_match('/^Bearer\s+(\S+)$/i', $h, $m) ? $m[1] : '';
    }

    private static function authorised()
    {
        $ip  = self::ip();
        $key = 'endora_mcp_fail_' . md5($ip);
        if ((int) get_transient($key) >= 20) {
            return 'locked';
        }
        $s   = self::settings();
        $tok = self::bearer();
        if ($s['token_hash'] !== '' && $tok !== '' && hash_equals($s['token_hash'], hash('sha256', $tok))) {
            return true;
        }
        set_transient($key, (int) get_transient($key) + 1, 600);
        return false;
    }

    /* ------------------------------------------------------------ JSON-RPC */
    public static function handle($request)
    {
        if (!is_ssl() && !(defined('ENDORA_MCP_ALLOW_HTTP') && ENDORA_MCP_ALLOW_HTTP)) {
            return new WP_REST_Response(['error' => 'HTTPS only'], 403);
        }
        $a = self::authorised();
        if ($a === 'locked') {
            return new WP_REST_Response(['error' => 'Too many wrong tokens. Try again in 10 minutes.'], 429);
        }
        if ($a !== true) {
            return new WP_REST_Response(['error' => 'Unauthorized'], 401);
        }
        $msg = json_decode((string) $request->get_body(), true);
        if (!is_array($msg)) {
            return self::rpc_error(null, -32700, 'Parse error');
        }
        if (isset($msg[0])) { // batch
            $out = [];
            foreach ($msg as $m) {
                $r = self::dispatch($m);
                if ($r !== null) {
                    $out[] = $r;
                }
            }
            return $out ? new WP_REST_Response($out, 200) : new WP_REST_Response(null, 202);
        }
        $r = self::dispatch($msg);
        return $r === null ? new WP_REST_Response(null, 202) : new WP_REST_Response($r, 200);
    }

    private static function rpc_error($id, $code, $message)
    {
        return new WP_REST_Response(['jsonrpc' => '2.0', 'id' => $id, 'error' => ['code' => $code, 'message' => $message]], 200);
    }

    public static function dispatch($m)
    {
        $id     = $m['id'] ?? null;
        $method = (string) ($m['method'] ?? '');
        $p      = (array) ($m['params'] ?? []);
        $isNote = !array_key_exists('id', $m);
        try {
            switch ($method) {
                case 'initialize':
                    $res = ['protocolVersion' => $p['protocolVersion'] ?? self::PROTOCOL, 'capabilities' => ['tools' => ['listChanged' => false]], 'serverInfo' => ['name' => 'endora-mcp', 'version' => self::VERSION],
                        'instructions' => 'Endora site and server tools. Ask the owner before deleting or overwriting anything. Deletes are permanent unless mode=trash.'];
                    break;
                case 'ping':
                    $res = new stdClass();
                    break;
                case 'tools/list':
                    $res = ['tools' => self::tool_defs()];
                    break;
                case 'tools/call':
                    $res = self::call((string) ($p['name'] ?? ''), (array) ($p['arguments'] ?? []));
                    break;
                default:
                    if ($isNote) {
                        return null;
                    }
                    return ['jsonrpc' => '2.0', 'id' => $id, 'error' => ['code' => -32601, 'message' => 'Method not found']];
            }
        } catch (Throwable $e) {
            if ($isNote) {
                return null;
            }
            return ['jsonrpc' => '2.0', 'id' => $id, 'error' => ['code' => -32603, 'message' => $e->getMessage()]];
        }
        return $isNote ? null : ['jsonrpc' => '2.0', 'id' => $id, 'result' => $res];
    }

    /* ------------------------------------------------------------ tools */
    private static function tool_defs()
    {
        $o = function ($props, $req = []) { return ['type' => 'object', 'properties' => (object) $props, 'required' => $req]; };
        $str = ['type' => 'string'];
        $int = ['type' => 'integer'];
        $bool = ['type' => 'boolean'];
        return [
            ['name' => 'site_info', 'description' => 'PHP/WordPress versions, server paths, free disk space, active plugins.', 'inputSchema' => $o([])],
            ['name' => 'disk_usage', 'description' => 'Size of each folder/file directly inside a path (biggest first). Use it to find what fills the hosting space.', 'inputSchema' => $o(['path' => $str, 'limit' => $int])],
            ['name' => 'list_files', 'description' => 'List a folder: name, type, size, modified time.', 'inputSchema' => $o(['path' => $str, 'sort' => ['type' => 'string', 'enum' => ['name', 'size', 'mtime']]])],
            ['name' => 'find_files', 'description' => 'Find files under a path by name pattern (e.g. *.log, *.zip) and/or minimum size in MB; returns the biggest matches.', 'inputSchema' => $o(['path' => $str, 'pattern' => $str, 'min_mb' => ['type' => 'number'], 'limit' => $int])],
            ['name' => 'read_file', 'description' => 'Read a text file (default first 200 KB).', 'inputSchema' => $o(['path' => $str, 'max_bytes' => $int], ['path'])],
            ['name' => 'write_file', 'description' => 'Create or overwrite a file. Needs "Allow writing files" in the Endora MCP menu. Backs up an existing file first; PHP files are syntax-checked before they go live.', 'inputSchema' => $o(['path' => $str, 'content' => $str], ['path', 'content'])],
            ['name' => 'delete_path', 'description' => 'Delete a file or folder. Needs "Allow deleting" in the Endora MCP menu. mode=permanent (default) frees the space; mode=trash moves it to .endora-trash. Only call after the owner has confirmed the exact paths.', 'inputSchema' => $o(['path' => $str, 'mode' => ['type' => 'string', 'enum' => ['permanent', 'trash']]], ['path'])],
            ['name' => 'db_query', 'description' => 'Run a read-only SQL query (SELECT/SHOW/DESCRIBE) on the WordPress database. Add a Perfex CRM query through run_php.', 'inputSchema' => $o(['sql' => $str, 'limit' => $int], ['sql'])],
            ['name' => 'run_php', 'description' => 'Run PHP inside WordPress (like WP-CLI eval). Needs "Allow running PHP" in the Endora MCP menu. Returns the printed output and the returned value.', 'inputSchema' => $o(['code' => $str], ['code'])],
        ];
    }

    private static function text($v, $err = false)
    {
        $t = is_string($v) ? $v : wp_json_encode($v, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        return ['content' => [['type' => 'text', 'text' => (string) $t]], 'isError' => $err];
    }

    private static function call($name, $a)
    {
        $s = self::settings();
        $log = ['t' => gmdate('Y-m-d H:i:s'), 'tool' => $name, 'ip' => self::ip(), 'args' => mb_substr(wp_json_encode(array_map(function ($v) { return is_string($v) && strlen($v) > 160 ? substr($v, 0, 160) . '…' : $v; }, $a)), 0, 400), 'ok' => 1];
        try {
            $r = self::run_tool($name, $a, $s);
        } catch (Throwable $e) {
            $log['ok'] = 0;
            $log['err'] = mb_substr($e->getMessage(), 0, 200);
            self::log($log);
            return self::text('Error: ' . $e->getMessage(), true);
        }
        self::log($log);
        return self::text($r);
    }

    private static function log($row)
    {
        $l = (array) get_option(self::LOG, []);
        array_unshift($l, $row);
        update_option(self::LOG, array_slice($l, 0, 300), false);
    }

    /** A path inside the allowed root (the folder above public_html by default), or an exception. */
    private static function safe($path, $mustExist = true)
    {
        $root = self::root();
        $path = (string) $path;
        if ($path === '' || $path === '.') {
            return $root;
        }
        $full = $path[0] === '/' ? $path : $root . '/' . $path;
        $full = preg_replace('#/+#', '/', $full);
        if (strpos($full, "\0") !== false) {
            throw new Exception('Bad path.');
        }
        $real = realpath($full);
        if ($real === false) {
            if ($mustExist) {
                throw new Exception('Not found: ' . $path);
            }
            $parent = realpath(dirname($full));
            if ($parent === false) {
                throw new Exception('Folder does not exist: ' . dirname($path));
            }
            $real = $parent . '/' . basename($full);
        }
        if ($real !== $root && strpos($real, $root . '/') !== 0) {
            throw new Exception('Outside the allowed folder (' . $root . ').');
        }
        return $real;
    }

    private static function protected_path($p)
    {
        $root = self::root();
        $abs  = rtrim(realpath(ABSPATH) ?: ABSPATH, '/');
        $self = realpath(__DIR__) ?: __DIR__;
        if ($p === $root || $p === $abs || $p === dirname($abs) || $p === $self || strpos($self, $p . '/') === 0 || strpos($abs, $p . '/') === 0) {
            return true; // the root, WordPress itself, the folders above it, or this plugin
        }
        return in_array(basename($p), ['wp-config.php'], true) && dirname($p) === $abs;
    }

    private static function size($p)
    {
        if (is_file($p) || is_link($p)) {
            return (int) @filesize($p);
        }
        $q = escapeshellarg($p);
        if (function_exists('shell_exec') && stripos((string) ini_get('disable_functions'), 'shell_exec') === false) {
            $o = @shell_exec('du -sk ' . $q . ' 2>/dev/null');
            if ($o !== null && preg_match('/^(\d+)/', $o, $m)) {
                return (int) $m[1] * 1024;
            }
        }
        $t = 0;
        $start = microtime(true);
        try {
            foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($p, FilesystemIterator::SKIP_DOTS)) as $f) {
                $t += (int) @$f->getSize();
                if (microtime(true) - $start > 8) {
                    break;
                }
            }
        } catch (Throwable $e) {
        }
        return $t;
    }

    private static function hum($b)
    {
        foreach (['B', 'KB', 'MB', 'GB', 'TB'] as $i => $u) {
            if ($b < pow(1024, $i + 1) || $u === 'TB') {
                return round($b / pow(1024, $i), 1) . ' ' . $u;
            }
        }
        return $b . ' B';
    }

    private static function run_tool($name, $a, $s)
    {
        switch ($name) {
            case 'site_info':
                $root = self::root();
                return [
                    'php' => PHP_VERSION, 'wordpress' => get_bloginfo('version'), 'site' => home_url(), 'abspath' => ABSPATH, 'allowed_root' => $root,
                    'disk_free' => self::hum((float) @disk_free_space($root)), 'disk_total' => self::hum((float) @disk_total_space($root)),
                    'active_plugins' => array_values((array) get_option('active_plugins', [])),
                    'switches' => ['write' => (bool) $s['allow_write'], 'delete' => (bool) $s['allow_delete'], 'php' => (bool) $s['allow_php']],
                ];
            case 'disk_usage':
                $p = self::safe($a['path'] ?? '');
                if (!is_dir($p)) {
                    throw new Exception('Not a folder.');
                }
                $rows = [];
                foreach (scandir($p) as $n) {
                    if ($n === '.' || $n === '..') {
                        continue;
                    }
                    $rows[] = ['name' => $n, 'type' => is_dir($p . '/' . $n) ? 'dir' : 'file', 'bytes' => self::size($p . '/' . $n)];
                }
                usort($rows, function ($x, $y) { return $y['bytes'] <=> $x['bytes']; });
                $rows = array_slice($rows, 0, max(1, min(100, (int) ($a['limit'] ?? 30))));
                foreach ($rows as &$r) {
                    $r['size'] = self::hum($r['bytes']);
                }
                return ['path' => $p, 'items' => $rows];
            case 'list_files':
                $p = self::safe($a['path'] ?? '');
                if (!is_dir($p)) {
                    throw new Exception('Not a folder.');
                }
                $rows = [];
                foreach (scandir($p) as $n) {
                    if ($n === '.' || $n === '..') {
                        continue;
                    }
                    $f = $p . '/' . $n;
                    $rows[] = ['name' => $n, 'type' => is_dir($f) ? 'dir' : 'file', 'size' => is_dir($f) ? null : (int) @filesize($f), 'modified' => gmdate('Y-m-d H:i', (int) @filemtime($f))];
                }
                $sort = $a['sort'] ?? 'name';
                usort($rows, function ($x, $y) use ($sort) { return $sort === 'size' ? (($y['size'] ?? 0) <=> ($x['size'] ?? 0)) : ($sort === 'mtime' ? strcmp($y['modified'], $x['modified']) : strcmp($x['name'], $y['name'])); });
                return ['path' => $p, 'count' => count($rows), 'items' => array_slice($rows, 0, 500)];
            case 'find_files':
                $p = self::safe($a['path'] ?? '');
                $pat = (string) ($a['pattern'] ?? '*');
                $min = (float) ($a['min_mb'] ?? 0) * 1048576;
                $lim = max(1, min(200, (int) ($a['limit'] ?? 50)));
                $out = [];
                $start = microtime(true);
                $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($p, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::LEAVES_ONLY, RecursiveIteratorIterator::CATCH_GET_CHILD);
                foreach ($it as $f) {
                    if (microtime(true) - $start > 15) {
                        break;
                    }
                    if (!$f->isFile() || $f->isLink() || !fnmatch($pat, $f->getFilename(), FNM_CASEFOLD) || $f->getSize() < $min) {
                        continue;
                    }
                    $out[] = ['path' => $f->getPathname(), 'bytes' => $f->getSize(), 'modified' => gmdate('Y-m-d', $f->getMTime())];
                }
                usort($out, function ($x, $y) { return $y['bytes'] <=> $x['bytes']; });
                $out = array_slice($out, 0, $lim);
                foreach ($out as &$r) {
                    $r['size'] = self::hum($r['bytes']);
                }
                return ['matches' => $out, 'note' => microtime(true) - $start > 15 ? 'Stopped after 15 s; narrow the path.' : ''];
            case 'read_file':
                $p = self::safe($a['path'] ?? '');
                if (!is_file($p)) {
                    throw new Exception('Not a file.');
                }
                $max = max(1, min(1048576, (int) ($a['max_bytes'] ?? 204800)));
                $d = (string) file_get_contents($p, false, null, 0, $max);
                return ['path' => $p, 'size' => filesize($p), 'truncated' => filesize($p) > $max, 'content' => $d];
            case 'write_file':
                if (!$s['allow_write']) {
                    throw new Exception('Writing is switched off. The owner can switch it on in the Endora MCP menu.');
                }
                $p = self::safe($a['path'] ?? '', false);
                if (self::protected_path($p)) {
                    throw new Exception('This path is protected.');
                }
                $c = (string) ($a['content'] ?? '');
                $dir = dirname($p);
                if (preg_match('/\.php$/i', $p)) {
                    $tmp = $dir . '/.endora-lint-' . wp_generate_password(8, false) . '.php';
                    file_put_contents($tmp, $c);
                    $bin = defined('PHP_BINARY') && PHP_BINARY ? PHP_BINARY : 'php';
                    $o = (string) @shell_exec(escapeshellarg($bin) . ' -l ' . escapeshellarg($tmp) . ' 2>&1');
                    @unlink($tmp);
                    if ($o !== '' && stripos($o, 'No syntax errors') === false && stripos($o, 'syntax') !== false) {
                        throw new Exception('PHP syntax error, file not written: ' . trim($o));
                    }
                }
                $backup = '';
                if (is_file($p)) {
                    $bd = self::root() . '/endora-backups';
                    wp_mkdir_p($bd);
                    $backup = $bd . '/' . basename($p) . '.' . time() . '.bak';
                    copy($p, $backup);
                }
                $tmp = $p . '.endora-tmp';
                if (file_put_contents($tmp, $c) === false || !rename($tmp, $p)) {
                    @unlink($tmp);
                    throw new Exception('Could not write the file.');
                }
                if (function_exists('opcache_invalidate')) {
                    @opcache_invalidate($p, true);
                }
                return ['written' => $p, 'bytes' => strlen($c), 'backup' => $backup];
            case 'delete_path':
                if (!$s['allow_delete']) {
                    throw new Exception('Deleting is switched off. The owner can switch it on in the Endora MCP menu.');
                }
                $p = self::safe($a['path'] ?? '');
                if (self::protected_path($p)) {
                    throw new Exception('This path is protected.');
                }
                $freed = self::size($p);
                if (($a['mode'] ?? 'permanent') === 'trash') {
                    $td = self::root() . '/.endora-trash';
                    wp_mkdir_p($td);
                    $to = $td . '/' . time() . '-' . basename($p);
                    if (!rename($p, $to)) {
                        throw new Exception('Could not move it to the trash folder.');
                    }
                    return ['moved_to' => $to, 'note' => 'The space is only freed when .endora-trash is emptied.'];
                }
                self::rrmdir($p);
                return ['deleted' => $p, 'freed' => self::hum($freed)];
            case 'db_query':
                global $wpdb;
                $sql = trim((string) ($a['sql'] ?? ''));
                if (!preg_match('/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN)\b/i', $sql) || preg_match('/;\s*\S/', $sql) || preg_match('/\b(INTO\s+(OUT|DUMP)FILE|LOAD_FILE|SLEEP\s*\()/i', $sql)) {
                    throw new Exception('Only a single read-only SELECT/SHOW/DESCRIBE query is allowed.');
                }
                $rows = $wpdb->get_results($sql, ARRAY_A);
                if ($wpdb->last_error) {
                    throw new Exception($wpdb->last_error);
                }
                return ['rows' => array_slice((array) $rows, 0, max(1, min(500, (int) ($a['limit'] ?? 100)))), 'total' => count((array) $rows)];
            case 'run_php':
                if (!$s['allow_php']) {
                    throw new Exception('Running PHP is switched off. The owner can switch it on in the Endora MCP menu.');
                }
                @set_time_limit(60);
                ob_start();
                try {
                    $ret = eval((string) ($a['code'] ?? ''));
                } catch (Throwable $e) {
                    $out = ob_get_clean();
                    return ['error' => $e->getMessage(), 'line' => $e->getLine(), 'output' => $out];
                }
                return ['output' => ob_get_clean(), 'return' => $ret];
        }
        throw new Exception('Unknown tool: ' . $name);
    }

    private static function rrmdir($p)
    {
        if (is_link($p) || is_file($p)) {
            if (!@unlink($p)) {
                throw new Exception('Could not delete ' . $p);
            }
            return;
        }
        foreach (scandir($p) as $n) {
            if ($n !== '.' && $n !== '..') {
                self::rrmdir($p . '/' . $n);
            }
        }
        if (!@rmdir($p)) {
            throw new Exception('Could not remove folder ' . $p);
        }
    }

    /* ------------------------------------------------------------ admin page */
    public static function admin_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $new = '';
        if (!empty($_POST['endora_mcp']) && check_admin_referer('endora_mcp')) {
            $s = self::settings();
            if (!empty($_POST['new_token'])) {
                $new = 'emcp_' . wp_generate_password(40, false, false);
                $s['token_hash'] = hash('sha256', $new);
            }
            if (!empty($_POST['revoke'])) {
                $s['token_hash'] = '';
            }
            foreach (['allow_write', 'allow_delete', 'allow_php'] as $k) {
                $s[$k] = empty($_POST[$k]) ? 0 : 1;
            }
            $s['root'] = sanitize_text_field(wp_unslash($_POST['root'] ?? ''));
            update_option(self::OPT, $s, false);
            echo '<div class="updated"><p>Saved.</p></div>';
        }
        $s = self::settings();
        $url = esc_url(rest_url('endora-mcp/v1/mcp'));
        echo '<div class="wrap"><h1>Endora MCP</h1>';
        echo '<p>Connector address for Claude: <code>' . $url . '</code></p>';
        if ($new) {
            echo '<div class="notice notice-warning" style="padding:12px"><b>Your new token (shown only now, copy it):</b><br><code style="font-size:15px;user-select:all">' . esc_html($new) . '</code></div>';
        }
        echo '<form method="post">';
        wp_nonce_field('endora_mcp');
        echo '<input type="hidden" name="endora_mcp" value="1"><table class="form-table">';
        echo '<tr><th>Token</th><td>' . ($s['token_hash'] ? 'A token is set.' : 'No token yet (the connector is off).') . '<br><label><input type="checkbox" name="new_token" value="1"> Make a new token (the old one stops working)</label><br><label><input type="checkbox" name="revoke" value="1"> Switch the connector off (delete the token)</label></td></tr>';
        echo '<tr><th>Allowed folder</th><td><input class="regular-text" name="root" value="' . esc_attr($s['root']) . '" placeholder="' . esc_attr(self::root()) . '"><br><span class="description">Claude cannot touch anything outside this folder. Empty = the folder above WordPress.</span></td></tr>';
        echo '<tr><th>Allow</th><td>';
        foreach (['allow_write' => 'Writing files', 'allow_delete' => 'Deleting files and folders', 'allow_php' => 'Running PHP code (the most powerful switch)'] as $k => $l) {
            echo '<label><input type="checkbox" name="' . $k . '" value="1"' . checked($s[$k], 1, false) . '> ' . esc_html($l) . '</label><br>';
        }
        echo '<span class="description">Reading files, disk usage and read-only database queries are always on while a token exists. Keep the switches off when you are not using them.</span></td></tr></table>';
        submit_button('Save');
        echo '</form><h2>Last calls</h2><table class="widefat striped"><thead><tr><th>Time (UTC)</th><th>Tool</th><th>Details</th><th>IP</th><th>OK</th></tr></thead><tbody>';
        foreach (array_slice((array) get_option(self::LOG, []), 0, 60) as $r) {
            echo '<tr><td>' . esc_html($r['t']) . '</td><td>' . esc_html($r['tool']) . '</td><td><code>' . esc_html($r['args'] . (empty($r['err']) ? '' : ' → ' . $r['err'])) . '</code></td><td>' . esc_html($r['ip']) . '</td><td>' . ($r['ok'] ? '✔' : '✘') . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
}

Endora_MCP::init();
